module.exports = {
    preset: 'ts-jest',
    testEnvironment: 'node',
    transform: {
        '^.+\\.tsx?$': ['ts-jest', {
            // ts-jest configuration goes here
            tsconfig: {
                esModuleInterop: true,
            },
        }],
    },
    moduleFileExtensions: ['ts', 'tsx', 'js', 'jsx', 'json', 'node'],
    testMatch: ['**/__tests__/**/*.ts'], // Specifies the test files pattern
    collectCoverage: true, // Enables coverage collection
    collectCoverageFrom: ['src/**/*.{ts,tsx}', '!src/**/*.d.ts'], // Specifies files for which to collect coverage
    coverageDirectory: 'coverage', // Specifies the directory for coverage reports
    coverageReporters: ['text', 'lcov'] // Specifies the coverage report formats
};

