declare module 'merkle-tree' {
    export function hash(data: string): string;

    export class MerkleTree {
        constructor(leaves: string[]);
        getRoot(): string;
        getProof(leafValue: string): string[];
        static verifyProof(leafValue: string, proof: string[], root: string): boolean;
    }

    export class MerkleNode {
        value: string;
        left: MerkleNode | null;
        right: MerkleNode | null;
        constructor(value: string, left?: MerkleNode | null, right?: MerkleNode | null);
    }
}
