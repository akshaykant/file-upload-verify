"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MerkleTree = void 0;
const MerkleNode_1 = __importDefault(require("./MerkleNode"));
const HashFunction_1 = require("./HashFunction");
/**
 * Represents a Merkle tree and provides methods to construct the tree,
 * generate proofs, and verify proofs.
 */
class MerkleTree {
    /**
     * Constructs a Merkle tree from the given list of leaf values.
     * @param leaves - The list of leaf values (file hashes).
     */
    constructor(leaves) {
        // Store hashes of the leaves
        this.leaves = leaves.map(data => new MerkleNode_1.default((0, HashFunction_1.hash)(data)));
        this.root = this.buildTree(this.leaves);
    }
    /**
     * Recursively builds the Merkle tree from the given list of nodes.
     * @param nodes - The list of nodes at the current level of the tree.
     * @returns The root node of the tree.
     */
    buildTree(nodes) {
        if (nodes.length === 1)
            return nodes[0];
        let parents = [];
        for (let i = 0; i < nodes.length; i += 2) {
            const left = nodes[i];
            const right = i + 1 < nodes.length ? nodes[i + 1] : left; // Duplicate last if odd number of nodes
            const parentHash = (0, HashFunction_1.hash)(left.value + right.value);
            parents.push(new MerkleNode_1.default(parentHash, left, right));
        }
        return this.buildTree(parents);
    }
    /**
     * Returns the root hash of the Merkle tree.
     * @returns The root hash as a string.
     */
    getRoot() {
        return this.root.value;
    }
    /**
     * Generates a proof for the given leaf value.
     * @param leafValue - The raw leaf value for which to generate the proof.
     * @returns The list of sibling hashes constituting the proof.
     */
    getProof(leafValue) {
        const leafHash = (0, HashFunction_1.hash)(leafValue);
        let index = this.leaves.findIndex(node => node.value === leafHash);
        if (index === -1)
            throw new Error('Leaf not found in the tree');
        let proof = [];
        let layer = this.leaves;
        while (layer.length > 1) {
            const pairIndex = index % 2 === 0 ? index + 1 : index - 1; // Get the sibling index
            if (pairIndex < layer.length) {
                const siblingHash = layer[pairIndex].value;
                const proofElement = (pairIndex < index ? '0x0' : '0x1') + siblingHash;
                proof.push(proofElement);
            }
            index = Math.floor(index / 2); // Move up to the next layer
            layer = this.getNextLayer(layer);
        }
        return proof;
    }
    getNextLayer(layer) {
        let parents = [];
        for (let i = 0; i < layer.length; i += 2) {
            const left = layer[i];
            const right = i + 1 < layer.length ? layer[i + 1] : left; // Duplicate last if odd number of nodes
            const parentHash = (0, HashFunction_1.hash)(left.value + right.value);
            parents.push(new MerkleNode_1.default(parentHash, left, right));
        }
        return parents;
    }
    static verifyProof(leafValue, proof, root) {
        let computedHash = (0, HashFunction_1.hash)(leafValue); // Start with the leaf node's hash
        // Each element in the proof array should contain the hash and whether it's a left (0x0) or right (0x1) sibling
        proof.forEach(proofElement => {
            const isLeftSibling = proofElement.slice(0, 3) === '0x0';
            const siblingHash = proofElement.slice(3);
            // Concatenate and hash based on sibling position
            if (isLeftSibling) {
                computedHash = (0, HashFunction_1.hash)(siblingHash + computedHash); // Sibling is left, so it comes first
            }
            else {
                computedHash = (0, HashFunction_1.hash)(computedHash + siblingHash); // Sibling is right, so it comes second
            }
        });
        return computedHash === root; // Check if the recomputed root matches the given root hash
    }
}
exports.MerkleTree = MerkleTree;
