import { createHash } from 'crypto';

/**
 * Hashes the given data using SHA-256.
 * @param data - The input string to hash.
 * @returns The resulting hash as a hexadecimal string.
 */
export const hash = (data: string): string => {
    return createHash('sha256').update(data).digest('hex');
};

