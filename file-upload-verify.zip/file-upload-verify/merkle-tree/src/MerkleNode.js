"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MerkleNode = void 0;
/**
 * Represents a node in the Merkle tree.
 */
class MerkleNode {
    constructor(value, left = null, right = null) {
        this.value = value;
        this.left = left;
        this.right = right;
    }
}
exports.MerkleNode = MerkleNode;
exports.default = MerkleNode;
