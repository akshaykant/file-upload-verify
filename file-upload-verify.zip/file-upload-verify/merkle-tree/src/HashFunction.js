"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.hash = void 0;
const crypto_1 = require("crypto");
/**
 * Hashes the given data using SHA-256.
 * @param data - The input string to hash.
 * @returns The resulting hash as a hexadecimal string.
 */
const hash = (data) => {
    return (0, crypto_1.createHash)('sha256').update(data).digest('hex');
};
exports.hash = hash;
