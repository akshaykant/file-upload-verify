### Merkle Tree File Integrity Verification System

This project implements a Merkle tree in TypeScript for file integrity verification. It is designed to be used as a library for client and servers to manage file uploads, create root hashes for files, generate Merkle proofs for individual files, and verify these proofs to ensure the integrity and authenticity of files stored on a server.

### Overview
The system uses a Merkle tree to ensure data integrity and provide a secure way of verifying file contents without needing to compare the entire data set. Each file's content is hashed, and these hashes are used as leaves in the Merkle tree. The Merkle root provides a fingerprint of all the file data, allowing efficient and secure verification.

### Getting Started

#### Installation

Clone the repository and install dependencies:

```
git clone https://github.com/your-repo/merkle-tree.git
cd merkle-tree
npm install
```

### Building the Project
Compile the TypeScript files to JavaScript:

```
npm run build
```

### Running Tests
Execute tests to ensure the system works as expected:

```
npm run test:coverage
```

### Usage 

#### Creating the Merkle Tree
To create a Merkle tree from a list of files (or their data):

```
import MerkleTree from './src/MerkleTree';

// Simulate file data as strings
const fileData = ['data from file1', 'data from file2', 'data from file3'];
const tree = new MerkleTree(fileData);

const rootHash = tree.getRoot();
console.log('Merkle Root Hash:', rootHash);
```

#### Generating Proofs
Generate a proof for a file to validate its integrity later without needing the entire file data:

```
const proofForFile1 = tree.getProof('data from file1');
console.log('Proof for File 1:', proofForFile1);
```


#### Verifying Proofs

Verify the proof of a file against the Merkle root:

```
const isValid = MerkleTree.verifyProof('data from file1', proofForFile1, rootHash);
console.log('Is the proof valid?', isValid);
```

### How It Works

#### Tree Construction:

The tree is built from the bottom up. Each leaf node represents a hashed file.
Pairs of leaf nodes are hashed together to form their parent nodes.
This process continues until a single root node is formed, which is the Merkle root.

#### Proof Generation:

A Merkle proof is a series of hashes that allows one to verify a specific leaf's(file's) inclusion in the tree.
To generate a proof, traverse from the leaf to the root, collecting the hash of each sibling node along the path.

#### Verification:

To verify a leaf (file), start with its hash and iteratively hash it with the provided sibling hashes.
If the final hash matches the root hash, the proof is valid, and the leaf is part of the tree.

#### Explanation on Proof Elements
Each proof element contains a prefix 0x0 or 0x1 followed by the sibling hash:

`0x0` indicates that the sibling is a left node.

`0x1` indicates that the sibling is a right node.

This allows the verification function to reconstruct the path from the leaf to the root accurately.