import {MerkleTree} from '../src/MerkleTree';
import { hash } from '../src/HashFunction';

describe('MerkleTree', () => {
    it('should construct a Merkle tree and generate the correct root hash', () => {
        const leaves = ['a', 'b', 'c', 'd'];
        const tree = new MerkleTree(leaves);
        expect(tree.getRoot()).toBeDefined();
    });

    it('should generate a correct proof and verify it', () => {
        const leaves = ['a', 'b', 'c', 'd'];
        const tree = new MerkleTree(leaves);
        const proof = tree.getProof('b');
        const root = tree.getRoot();
        expect(MerkleTree.verifyProof('b', proof, root)).toBe(true);
    });

    it('should not verify an incorrect proof', () => {
        const leaves = ['a', 'b', 'c', 'd'];
        const tree = new MerkleTree(leaves);
        const proof = tree.getProof('b');
        const root = tree.getRoot();
        expect(MerkleTree.verifyProof('x', proof, root)).toBe(false);
    });

    it('should handle an odd number of leaves by duplicating the last leaf', () => {
        const leaves = ['a', 'b', 'c'];
        const tree = new MerkleTree(leaves);
        expect(tree.getRoot()).toBeDefined();
    });

    it('should generate and verify proofs for all leaves', () => {
        const leaves = ['a', 'b', 'c', 'd'];
        const tree = new MerkleTree(leaves);
        leaves.forEach(leaf => {
            const proof = tree.getProof(leaf);
            const root = tree.getRoot();
            expect(MerkleTree.verifyProof(leaf, proof, root)).toBe(true);
        });
    });

    it('should handle a single leaf correctly', () => {
        const leaves = ['a'];
        const tree = new MerkleTree(leaves);
        expect(tree.getRoot()).toBe(hash('a'));
        const proof = tree.getProof('a');
        expect(MerkleTree.verifyProof('a', proof, tree.getRoot())).toBe(true);
    });
});
