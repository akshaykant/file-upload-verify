"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const MerkleTree_1 = __importDefault(require("../src/MerkleTree"));
const HashFunction_1 = require("../src/HashFunction");
describe('MerkleTree', () => {
    it('should construct a Merkle tree and generate the correct root hash', () => {
        const leaves = ['a', 'b', 'c', 'd'];
        const tree = new MerkleTree_1.default(leaves);
        expect(tree.getRoot()).toBeDefined();
    });
    it('should generate a correct proof and verify it', () => {
        const leaves = ['a', 'b', 'c', 'd'];
        const tree = new MerkleTree_1.default(leaves);
        const proof = tree.getProof('b');
        const root = tree.getRoot();
        expect(MerkleTree_1.default.verifyProof('b', proof, root)).toBe(true);
    });
    it('should not verify an incorrect proof', () => {
        const leaves = ['a', 'b', 'c', 'd'];
        const tree = new MerkleTree_1.default(leaves);
        const proof = tree.getProof('b');
        const root = tree.getRoot();
        expect(MerkleTree_1.default.verifyProof('x', proof, root)).toBe(false);
    });
    it('should handle an odd number of leaves by duplicating the last leaf', () => {
        const leaves = ['a', 'b', 'c'];
        const tree = new MerkleTree_1.default(leaves);
        expect(tree.getRoot()).toBeDefined();
    });
    it('should generate and verify proofs for all leaves', () => {
        const leaves = ['a', 'b', 'c', 'd'];
        const tree = new MerkleTree_1.default(leaves);
        leaves.forEach(leaf => {
            const proof = tree.getProof(leaf);
            const root = tree.getRoot();
            expect(MerkleTree_1.default.verifyProof(leaf, proof, root)).toBe(true);
        });
    });
    it('should handle a single leaf correctly', () => {
        const leaves = ['a'];
        const tree = new MerkleTree_1.default(leaves);
        expect(tree.getRoot()).toBe((0, HashFunction_1.hash)('a'));
        const proof = tree.getProof('a');
        expect(MerkleTree_1.default.verifyProof('a', proof, tree.getRoot())).toBe(true);
    });
});
