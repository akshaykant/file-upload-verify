#  File Upload Server

This server application is responsible for storing files, generating Merkle trees, and providing Merkle proofs on request. It is built with Node.js and Express and uses TypeScript for type safety.

## Project Structure

```
server
├── routes
│ └──apiRoutes.ts
├── index.ts
├── controllers
│ └── ServerController.ts
├── services
│ ├── FileService.ts
│ └── MerkleService.ts
├── utils
│ ├── FileUtils.ts
│ └── logger.ts
├── models
│ └── response.ts
├── validations
│ └── validation.ts
├── Dockerfile
└── README.md
```


## API Endpoints

### POST /server/upload

Uploads multiple files to the server and generates a new Merkle root.

**Request Body:**
```json
{
  "files": [
    {
      "filename": "file1.txt",
      "content": "base64_encoded_content1"
    },
    {
      "filename": "file2.txt",
      "content": "base64_encoded_content2"
    }
  ]
}
```
Response:

```json
{
  "success": true,
  "data": {
    "status": "Files uploaded successfully",
    "rootHash": "root_hash_value"
  },
  "message": "Files uploaded successfully"
}

```

### GET /server/proof/:filename

Provides the Merkle proof for a given file.

Response:

```json
{
  "success": true,
  "data": {
    "proof": "proof1",
    "filename": "file1.txt",
    "content": "base64_encoded_content1"
  }
}

```

### Configuration

The server configuration is stored in config/config.ts and includes settings for the environment, file size limit, maximum number of files, and other parameters.

### Running the Project

#### Running the Server

```
docker-compose up --build
```
#### Upload Files:

```
curl -X POST http://localhost:3000/server/upload -d '{"files":[{"filename":"file1.txt","content":"base64_encoded_content1"},{"filename":"file2.txt","content":"base64_encoded_content2"}]}' -H "Content-Type: application/json"
```

#### Get File and Merkle Proof:
```
curl -X GET http://localhost:3000/server/proof/:filename


```

### Logging

The server uses Winston for logging, with logs stored in the logs directory.

```
logs
├── server-file-upload-verify-YYYY-MM-DD.log

```