import FileService from './FileService';
import { MerkleTree } from "merkle-tree/dist/MerkleTree";

class MerkleService {
    private fileService: FileService;

    constructor() {
        this.fileService = new FileService();
    }

    async generateMerkleRoot(): Promise<string> {
        const allFileContents = await this.fileService.getAllFileContents();
        const tree = new MerkleTree(allFileContents.sort());
        return tree.getRoot();
    }

    async getProof(filename: string): Promise<string[]> {
        const fileContent = await this.fileService.getFileContent(filename);
        const allFileContents = await this.fileService.getAllFileContents();
        const tree = new MerkleTree(allFileContents.sort());
        return tree.getProof(fileContent);
    }
}

export default MerkleService;
