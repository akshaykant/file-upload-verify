import fs from 'fs';
import path from 'path';
import logger from '../utils/logger';
const config = require('config');

class FileService {
    private readonly FILES_DIR = config.get('file.uploadDirectory');

    constructor() {
        if (!fs.existsSync(this.FILES_DIR)) {
            fs.mkdirSync(this.FILES_DIR);
        }
    }

    async saveFile(filename: string, content: string): Promise<void> {
        const filePath = path.join(this.FILES_DIR, filename);
        fs.writeFileSync(filePath, content, 'utf-8');
        logger.info(`File saved: ${filename}`);
    }

    async getFileContent(filename: string): Promise<string> {
        const filePath = path.join(this.FILES_DIR, filename);
        if (!fs.existsSync(filePath)) {
            throw new Error('File not found');
        }
        return fs.readFileSync(filePath, 'utf-8');
    }

    async getAllFileContents(): Promise<string[]> {
        const files = fs.readdirSync(this.FILES_DIR);
        return files.map(file => fs.readFileSync(path.join(this.FILES_DIR, file), 'utf-8'));
    }
}

export default FileService;
