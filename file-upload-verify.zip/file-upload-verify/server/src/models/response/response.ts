export interface SuccessResponse {
    success: true;
    data: any;
    message: string;
}

export interface ErrorResponse {
    success: false;
    error: string;
}