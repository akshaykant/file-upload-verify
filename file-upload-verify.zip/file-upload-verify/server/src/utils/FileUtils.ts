import fs from 'fs';
import path from 'path';
import { MerkleTree} from "merkle-tree/dist/MerkleTree";
import { hash} from "merkle-tree/dist/HashFunction";
const config = require('config');

class FileUtils {
    private readonly UPLOADED_FILES_INFO = config.get('uploadedFilesInfo');

    loadUploadedFiles(): Record<string, string> {
        if (!fs.existsSync(this.UPLOADED_FILES_INFO)) {
            return {};
        }
        return JSON.parse(fs.readFileSync(this.UPLOADED_FILES_INFO, 'utf-8'));
    }

    saveUploadedFiles(uploadedFiles: Record<string, string>): void {
        fs.writeFileSync(this.UPLOADED_FILES_INFO, JSON.stringify(uploadedFiles, null, 2));
    }

    hash(data: string): string {
        return hash(data);
    }

    generateProof(fileContent: string): string[] {
        const files = this.loadUploadedFiles();
        const fileData = Object.keys(files).map(file => fs.readFileSync(path.join(__dirname, `../../uploads/${file}`), 'utf-8')).sort();
        const tree = new MerkleTree(fileData);
        return tree.getProof(fileContent);
    }
}

export default FileUtils;
