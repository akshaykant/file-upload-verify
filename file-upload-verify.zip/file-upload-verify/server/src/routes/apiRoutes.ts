import { Router } from 'express';
import ServerController from "../controllers/ServerController";

const router = Router();
const serverController = new ServerController();

router.post('/upload', serverController.uploadFiles);
router.get('/proof/:filename', serverController.getProof);

// Admin pingCheck route
router.get('/admin/pingCheck', (req, res) => {
    // You can customize the response message as needed
    res.status(200).send('Server Application is alive and healthy.');
});

export { router as apiRoutes };


