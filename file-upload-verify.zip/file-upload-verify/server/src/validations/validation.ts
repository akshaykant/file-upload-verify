import { Request, Response } from 'express';
import {ErrorResponse} from "../models/response/response";
const config = require('config');

export const validateUpload = (req: Request, res: Response): ErrorResponse | null => {
    const { files } = req.body;

    if (!files || !Array.isArray(files) || files.length === 0) {
        return { success: false, error: 'Files are required' };
    }

    if (files.length > config.get('file.maxFiles')) {
        return { success: false, error: `Too many files. Maximum is ${config.get('file.maxFiles')}` };
    }

    for (const file of files) {
        if (Buffer.from(file.content, 'base64').length > config.get('file.sizeLimit')) {
            return { success: false, error: `File ${file.filename} is too large. Maximum size is ${config.get('file.sizeLimit') / 1024}KB` };
        }
    }

    return null;
};

export const validateFilename = (req: Request, res: Response): ErrorResponse | null => {
    const { filename } = req.params;
    if (!filename) {
        return { success: false, error: 'Filename is required' };
    }
    return null;
};
