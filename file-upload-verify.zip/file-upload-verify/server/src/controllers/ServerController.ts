import { Request, Response } from 'express';
import FileService from '../services/FileService';
import MerkleService from '../services/MerkleService';
import logger from '../utils/logger';
import { validateUpload, validateFilename } from '../validations/validation';
import {ErrorResponse, SuccessResponse} from "../models/response/response";

class ServerController {
    private fileService: FileService;
    private merkleService: MerkleService;

    constructor() {
        this.fileService = new FileService();
        this.merkleService = new MerkleService();
    }

    async uploadFiles(req: Request, res: Response) {
        const validationError = validateUpload(req, res);
        if (validationError) {
            return res.status(400).json(validationError);
        }

        const { files } = req.body;

        try {
            for (const file of files) {
                const content = Buffer.from(file.content, 'base64').toString('utf-8');
                await this.fileService.saveFile(file.filename, content);
            }

            const rootHash = await this.merkleService.generateMerkleRoot();
            const response: SuccessResponse = {
                success: true,
                data: { rootHash },
                message: 'Files uploaded successfully',
            };
            res.status(200).json(response);
        } catch (error : any) {
            logger.error(`Upload files error: ${error.message}`);
            const response: ErrorResponse = {
                success: false,
                error: error.message,
            };
            res.status(500).json(response);
        }
    }

    async getProof(req: Request, res: Response) {
        const validationError = validateFilename(req, res);
        if (validationError) {
            return res.status(400).json(validationError);
        }

        try {
            const { filename } = req.params;
            const fileContent = await this.fileService.getFileContent(filename);
            const proof = await this.merkleService.getProof(filename);
            const base64Content = Buffer.from(fileContent, 'utf-8').toString('base64');

            const response: SuccessResponse = {
                success: true,
                data: { filename, content: base64Content, proof },
                message: 'Get File proof successful',
            };
            res.status(200).json(response);
        } catch (error : any) {
            logger.error(`Get proof error: ${error.message}`);
            const response: ErrorResponse = {
                success: false,
                error: error.message,
            };
            res.status(500).json(response);
        }
    }
}

export default ServerController;
