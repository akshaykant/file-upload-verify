import winston from 'winston';
import DailyRotateFile from 'winston-daily-rotate-file';
import moment from 'moment';

// Function to get current log filename
function getCurrentLogFilename() {
    const currentDate = moment().format('YYYY-MM-DD');
    return `client-file-upload-verify-${currentDate}.log`;
}

// Create a winston format to inject the filename
const customFormat = winston.format.printf(({ level, message, timestamp }) => {
    return `${timestamp} SN=${getCurrentLogFilename()} ${level}: ${message}`;
});

const dailyRotateTransport = new DailyRotateFile({
    filename: 'logs/client-file-upload-verify-%DATE%.log',
    datePattern: 'YYYY-MM-DD',
    maxSize: '100m',
});

const logger = winston.createLogger({
    level: 'info',
    format: winston.format.combine(
        winston.format.timestamp({
           format: 'YYYY-MM-DD HH:mm:ss',
        }),
        customFormat
    ),
    transports: [
        new winston.transports.Console(),
        dailyRotateTransport],
});


export default logger;
