import fs from 'fs';
import { hash } from "merkle-tree/dist/HashFunction";
const config = require('config');

class FileUtils {
    private readonly UPLOADED_FILES_INFO = config.get('file.uploadedFilesInfo');

    loadUploadedFiles(): Record<string, string> {
        if (!fs.existsSync(this.UPLOADED_FILES_INFO)) {
            return {};
        }
        return JSON.parse(fs.readFileSync(this.UPLOADED_FILES_INFO, 'utf-8'));
    }

    saveUploadedFiles(uploadedFiles: Record<string, string>): void {
        fs.writeFileSync(this.UPLOADED_FILES_INFO, JSON.stringify(uploadedFiles, null, 2));
    }

    hash(data: string): string {
        return hash(data);
    }
}

export default FileUtils;
