import { Request, Response } from 'express';
import fs from 'fs';
import { ErrorResponse } from '../models/response/response';

export const validateUpload = (req: Request, res: Response): ErrorResponse | null => {
    const { directory } = req.body.directory;
    if (!directory) {
        return { success: false, error: 'Directory is required' };
    }
    if (!fs.existsSync(directory) || !fs.statSync(directory).isDirectory()) {
        return { success: false, error: 'Directory does not exist or is not accessible' };
    }
    return null;
};

export const validateFilename = (req: Request, res: Response): ErrorResponse | null => {
    const { filename } = req.params.filename as any;
    if (!filename) {
        return { success: false, error: 'Filename is required' };
    }
    return null;
};
