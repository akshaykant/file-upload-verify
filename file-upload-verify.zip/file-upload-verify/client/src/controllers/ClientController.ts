import { Request, Response } from 'express';
import FileService from '../services/FileService';
import logger from '../utils/logger';
import { SuccessResponse, ErrorResponse} from '../models/response/response';
import { validateUpload, validateFilename } from '../validations/validation';

class ClientController {
    private fileService: FileService;

    constructor() {
        this.fileService = new FileService();
    }

    async uploadFiles(req: Request, res: Response) {
        const validationError = validateUpload(req, res);
        if (validationError) {
            return res.status(400).json(validationError);
        }

        try {
            const { directory } = req.body;
            const rootHash = await this.fileService.uploadFiles(directory);
            const response: SuccessResponse = {
                success: true,
                data: rootHash,
                message: 'Files uploaded successfully',
            };
            res.status(200).json(response);
        } catch (error : any) {
            logger.error(`Upload files error: ${error.message}`);
            const response: ErrorResponse = {
                success: false,
                error: error.message,
            };
            res.status(500).json(response);
        }
    }

    async getFiles(req: Request, res: Response) {
        try {
            const files = await this.fileService.getFiles();
            const response: SuccessResponse = {
                success: true,
                data: files,
                message: 'Files get successful',
            };
            res.status(200).json(response);
        } catch (error : any) {
            logger.error(`Get files error: ${error.message}`);
            const response: ErrorResponse = {
                success: false,
                error: error.message,
            };
            res.status(500).json(response);
        }
    }

    async getFile(req: Request, res: Response) {
        const validationError = validateFilename(req, res);
        if (validationError) {
            return res.status(400).json(validationError);
        }

        try {
            const { filename } = req.params;
            const result = await this.fileService.getFile(filename);
            const response: SuccessResponse = {
                success: true,
                data: result,
                message: 'File get successful',
            };
            res.status(200).json(response);
        } catch (error : any) {
            logger.error(`Get file error: ${error.message}`);
            const response: ErrorResponse = {
                success: false,
                error: error.message,
            };
            res.status(500).json(response);
        }
    }
}

export default ClientController;
