import { Router } from 'express';
import ClientController from "../controllers/ClientController";

const router = Router();
const clientController = new ClientController();

// Route to handle file upload
router.post('/upload', clientController.uploadFiles);
router.get('/files', clientController.getFiles);
router.get('/file/:filename', clientController.getFile);

// Admin pingCheck route
router.get('/admin/pingCheck', (req, res) => {
    // You can customize the response message as needed
    res.status(200).send('Client Application is alive and healthy.');
});

export { router as apiRoutes };