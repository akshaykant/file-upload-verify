import fs from 'fs';
import path from 'path';
import axios from 'axios';
import FileUtils from '../utils/FileUtils';
import logger from '../utils/logger';
import {MerkleTree} from "merkle-tree/dist/MerkleTree";
const config = require('config');

class FileService {
    private readonly FILE_SIZE_LIMIT = parseInt(config.get('file.sizeLimit'), 10);
    private readonly UPLOADED_FILES_INFO = config.get('file.uploadedFilesInfo');
    private readonly ROOT_HASH_FILE_NAME = config.get('file.rootHashFileName');
    private readonly SERVER_URL = config.get('server.url');
    private fileUtils: FileUtils;

    constructor() {
        this.fileUtils = new FileUtils();
        this.initializeFiles();
    }

    private initializeFiles() {
        // Ensure the uploads directory exists
        const uploadsDir = path.join(__dirname, '../../uploads');
        if (!fs.existsSync(uploadsDir)) {
            fs.mkdirSync(uploadsDir, { recursive: true });
        }

        // Ensure the uploadedFiles.json file exists
        if (!fs.existsSync(this.UPLOADED_FILES_INFO)) {
            fs.writeFileSync(this.UPLOADED_FILES_INFO, JSON.stringify({}));
        }

        // Ensure the rootHash.txt file exists
        if (!fs.existsSync(this.ROOT_HASH_FILE_NAME)) {
            fs.writeFileSync(this.ROOT_HASH_FILE_NAME, '');
        }
    }

    async uploadFiles(directory: string): Promise<string> {
        const files = fs.readdirSync(directory)
            .filter(file => fs.statSync(path.join(directory, file)).size <= this.FILE_SIZE_LIMIT);

        const fileData = files.map(file => fs.readFileSync(path.join(directory, file), 'utf-8')).sort(); // Ensure sorting
        const tree = new MerkleTree(fileData);
        const rootHash = tree.getRoot();

        const uploadedFiles = this.fileUtils.loadUploadedFiles();

        const filePayloads = [];
        for (const file of files) {
            const filePath = path.join(directory, file);
            const content = fs.readFileSync(filePath, 'utf-8');
            const fileHash = this.fileUtils.hash(content);

            // Check for duplicate
            if (!uploadedFiles[file]) {
                const encodedContent = Buffer.from(content).toString('base64');
                filePayloads.push({ filename: file, content: encodedContent });
                uploadedFiles[file] = fileHash;
                fs.unlinkSync(filePath); // Delete the file after upload
                logger.info(`File uploaded and deleted locally: ${file}`);
            }
        }

        if (filePayloads.length > 0) {
            await axios.post(`${this.SERVER_URL}/upload`, { files: filePayloads });
        }

        this.fileUtils.saveUploadedFiles(uploadedFiles);
        fs.writeFileSync(path.join(directory, this.ROOT_HASH_FILE_NAME), rootHash);

        return rootHash;
    }

    async getFiles(): Promise<object> {
        const uploadedFiles = this.fileUtils.loadUploadedFiles();
        const rootHash = fs.readFileSync(path.join(__dirname, `../../uploads/${this.ROOT_HASH_FILE_NAME}`), 'utf-8');
        return { files: uploadedFiles, rootHash };
    }

    async getFile(filename: string): Promise<object> {
        const response = await axios.get(`${this.SERVER_URL}/proof/${filename}`);
        // TODO : check data
        const { content, proof, filename: returnedFilename } = response.data.data;

        const rootHash = fs.readFileSync(path.join(__dirname, `../../uploads/${this.ROOT_HASH_FILE_NAME}`), 'utf-8');
        const isValid = MerkleTree.verifyProof(this.fileUtils.hash(content), proof, rootHash);

        if (!isValid) {
            throw new Error('File integrity verification failed');
        }

        const fileContent = Buffer.from(content, 'base64').toString('utf-8');

        return { fileContent, proof, rootHash, isValid, filename: returnedFilename };
    }
}

export default FileService;
