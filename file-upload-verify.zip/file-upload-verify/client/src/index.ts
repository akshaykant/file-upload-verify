import express from 'express';
import logger from './utils/logger';
import {apiRoutes} from "./routes/apiRoutes";

const config = require('config');

const app = express();
const PORT = config.get('app.port');
const env = config.get('app.env');

app.use(express.json());
app.use('/client', apiRoutes);

app.listen(PORT, () => {
    logger.info(`Client listening on port ${PORT} in environment ${env}.`);
});
