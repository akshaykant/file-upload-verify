import UploadController from "../src/controllers/ClientController";


describe('UploadController', () => {
    it('should return a welcome message', async () => {
        const req = {};
        const res = {
            send: jest.fn()
        };

        const welcomeController = new UploadController();
        await welcomeController.getWelcomeMessage(req, res);

        expect(res.send).toBeCalledWith('Welcome.ts to our API!');
    });
});


/*
*
* import axios, { AxiosRequestConfig } from 'axios';

interface Signature {
  // Define the structure of the Signature object here
  // based on your requirements
}

class CustodyService {
  private url: string;
  private apiKey: string;

  constructor(url: string, apiKey: string) {
    this.url = url;
    this.apiKey = apiKey;
  }

  async getWalletAddress(walletID: string, id: number): Promise<string> {
    const path = '/getaddress';

    // Set the request parameters
    const params = {
      walletID: walletID,
      id: id.toString()
    };

    // Set the request headers
    const headers = {
      'x-api-key': this.apiKey
    };

    // Set up the request configuration
    const config: AxiosRequestConfig = {
      url: this.url + path,
      method: 'GET',
      headers: headers,
      params: params
    };

    try {
      // Make the GET request to the external service
      const response = await axios(config);

      // Handle the response and return the wallet address
      const walletAddress = response.data.address;
      return walletAddress;
    } catch (error) {
      // Handle any errors that occurred during the request
      console.error('Error retrieving wallet address:', error);
      throw new Error('Failed to retrieve wallet address');
    }
  }

  async sendSignTransaction(walletID: string, messageHash: string): Promise<Signature> {
    const path = '/signTransaction';

    // Set the request body
    const data = {
      walletID: walletID,
      messageHash: messageHash
    };

    // Set the request headers
    const headers = {
      'x-api-key': this.apiKey
    };

    // Set up the request configuration
    const config: AxiosRequestConfig = {
      url: this.url + path,
      method: 'POST',
      headers: headers,
      data: data
    };

    try {
      // Make the POST request to the external service
      const response = await axios(config);

      // Handle the response and return the signature
      const signature: Signature = response.data.signature;
      return signature;
    } catch (error) {
      // Handle any errors that occurred during the request
      console.error('Error sending sign transaction request:', error);
      throw new Error('Failed to send sign transaction request');
    }
  }

  async getSignTransaction(txn: string): Promise<Signature> {
    const path = '/getTxn';

    // Set the request parameters
    const params = {
      txn: txn
    };

    // Set the request headers
    const headers = {
      'x-api-key': this.apiKey
    };

    // Set up the request configuration
    const config: AxiosRequestConfig = {
      url: this.url + path,
      method: 'GET',
      headers: headers,
      params: params
    };

    try {
      // Make the GET request to the external service
      const response = await axios(config);

      // Handle the response and return the signature
      const signature: Signature = response.data.signature;
      return signature;
    } catch (error) {
      // Handle any errors that occurred during the request
      console.error('Error retrieving sign transaction:', error);
      throw new Error('Failed to retrieve sign transaction');
    }
  }
}

// Usage example:
const custodyService = new CustodyService('https://external-service.com', 'API_KEY');

custodyService.getWalletAddress('wallet123', 1)
  .then((walletAddress) => {
    console.log('Wallet address:', walletAddress);
  })
  .catch((error) => {
    console.error('An error occurred:', error);
  });

custodyService.sendSignTransaction('wallet123', '0x123abc')
  .then((signature) => {
    console.log('Signature:', signature);
  })
  .catch((error) => {
    console.error('An error occurred:', error);
  });

custodyService.getSignTransaction('0x456def')
  .then((signature) => {
    console.log('Signature:', signature);
  })
  .catch((error) => {
    console.error('An error occurred:', error);
  });

* */