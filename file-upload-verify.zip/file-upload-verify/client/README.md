# File Upload Client

This client application is responsible for uploading files to a server, requesting files and their Merkle proofs, and verifying the integrity of the files using Merkle proofs. It is built with Node.js and Express and uses TypeScript for type safety.

## Project Structure

```
client
├── routes
│ └──apiRoutes.ts
├── index.ts
├── controllers
│ └── ClientController.ts
├── services
│ └── FileService.ts
├── utils
│ ├── FileUtils.ts
│ └── logger.ts
├── models
│ └── response.ts
├── validations
│ └── validation.ts
├── Dockerfile
└── README.md
```


## API Endpoints

### POST /client/upload

Upload files from a specified directory to the server.

**Request Body:**
```json
{
  "directory": "/path/to/directory"
}
```
Response:

```json
{
  "success": true,
  "data": {
    "status": "Files uploaded successfully",
    "rootHash": "root_hash_value"
  },
  "message": "Files uploaded successfully"
}
```

### GET /client/files

Lists all uploaded files and their hashes.

Response:

```json
{
"success": true,
"data": {
  "files": {
    "file1.txt": "hash1",
    "file2.txt": "hash2"
},
"rootHash": "root_hash_value"
}
}
```

### GET /client/file/:filename

Gets a file and its Merkle proof from the server and verifies the file's integrity.

Response:
```json
{
"success": true,
"data": {
  "fileContent": "file_content",
  "proof": "proof1",
  "rootHash": "root_hash_value",
  "isValid": true
}
}
```

### Configuration

The client configuration is stored in config/config.ts and includes settings for the environment, server URL, file size limit, and other parameters.


### Running the Client

#### Build and Run with Docker:

```
docker-compose up --build
```
#### Upload Files:

```
curl -X POST http://localhost:3001/client/upload -d '{"directory":"/app/uploads"}' -H "Content-Type: application/json"
```

#### List Uploaded Files and Their Hashes:
```
curl -X GET http://localhost:3001/client/files
```

#### Get File and Merkle Proof:
```
curl -X GET http://localhost:3001/client/file/:filename

```

### Logging

The client uses Winston for logging, with logs stored in the logs directory.

```
logs
├── client-file-upload-verify-YYYY-MM-DD.log

```