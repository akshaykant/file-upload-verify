### Running the Project

#### Start the Server and Client:

```
docker-compose up --build
```
#### Upload Files:

```
curl -X POST http://localhost:3001/client/upload -d '{"directory":"/app/uploads"}' -H "Content-Type: application/json"
```

#### List Uploaded Files and Their Hashes:
```
curl -X GET http://localhost:3001/client/files
```

#### Get File and Merkle Proof:
```
curl -X GET http://localhost:3001/client/file/:filename

```



### Docker Compose Configuration

**docker-compose.yml**

```yaml
version: '3.8'

services:
  server:
    build:
      context: ./server
      dockerfile: Dockerfile
    ports:
      - "3000:3000"
    environment:
      NODE_ENV: development
    volumes:
      - ./server/uploads:/app/uploads

  client:
    build:
      context: ./client
      dockerfile: Dockerfile
    ports:
      - "3001:3001"
    environment:
      NODE_ENV: development
    volumes:
      - ./client/uploads:/app/uploads
    depends_on:
      - server
```

### Approach
#### Client: 

The client uploads files to the server and handles requests for file verification by retrieving the Merkle proof from the server and validating it locally.


#### Server: 

The server stores files, generates Merkle trees, and provides Merkle proofs on request. It ensures file integrity by using Merkle trees to verify the content of files.


### Additional Information


#### File Size Limitation: 

The server is configured to accept files with a maximum size of 5KB each and a maximum of 1000 files per request.

#### Merkle Tree: 

A Merkle tree is used to verify the integrity of the files. The root hash is generated and stored after each upload, and proofs are generated on request to verify file integrity.